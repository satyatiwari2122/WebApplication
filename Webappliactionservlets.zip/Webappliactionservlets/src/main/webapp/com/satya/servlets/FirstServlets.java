package com.satya.servlets;

import javax.servlet.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class FirstServlets implements Servlet {
    ServletConfig servletConfig;

    @Override
    public void init(ServletConfig servletConfig) throws ServletException {
        this.servletConfig=servletConfig;
        System.out.println("creating Object......");
    }

    @Override
    public ServletConfig getServletConfig() {
        return this.servletConfig;
    }

    @Override
    public void service(ServletRequest servletRequest, ServletResponse servletResponse) throws ServletException, IOException {
        System.out.println("Providing service......");
        servletResponse.setContentType("text/html");
        PrintWriter printWriter =servletResponse.getWriter();
        printWriter.println("<h3>This is my servlet Code response...</h3>");
        printWriter.println("<h3>Todays date and time is: "+new Date().toString()+"</h3>");
    }

    @Override
    public String getServletInfo() {
        return "This servlet is created by Satya tiwari";
    }

    @Override
    public void destroy() {
        System.out.println("Destroying the Object");
    }
}
